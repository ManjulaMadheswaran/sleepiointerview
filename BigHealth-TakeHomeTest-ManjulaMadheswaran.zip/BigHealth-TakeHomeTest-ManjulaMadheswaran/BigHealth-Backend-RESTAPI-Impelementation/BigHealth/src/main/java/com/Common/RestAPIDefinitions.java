
package com.Common;

/**
 * @author Manjula Madheswaran
 * Common Rest API Call File ( which has all the API's used in this project )
 * keywords within curly braces is to get the dynamic value 
 */

public class RestAPIDefinitions {

	// Status Response Code with result parameter true / false 
	public static final String sucessCode = "200" ;
	public static final String failureFactor = "false" ;

	// GET API's
	public static final String get_bighealth = "https://onboarding.sleepio.com/sleepio/big-health";

}
