const Page = require('./page');
const common = require('../testData/common.json')

class landingPage extends Page {

    get getStarted () { return $("//*[@id='sl-flow']/div[3]/div/div/div/div/div/input") }

    open () {
        return super.open(common.url);
    }
    
    clickGetStarted(){
        this.getStarted.click();
    }

}

module.exports = new landingPage();
