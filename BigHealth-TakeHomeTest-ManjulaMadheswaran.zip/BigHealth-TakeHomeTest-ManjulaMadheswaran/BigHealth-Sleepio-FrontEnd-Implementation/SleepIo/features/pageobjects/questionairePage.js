const Page = require('./page');
const options = require('../testData/options.json')
const questions = require('../testData/questions.json')
const assert = require('assert')

class questionairePage extends Page {

    //Common locators
    get continue () { return $("//*[contains(text(),'Continue')]") }  
    get logo () { return $("//*[@id='sl-flow']/header/div/a[1]/img") }      
    get getStarted () { return $("//*[@id='sl-flow']/div[3]/div/div/div/div/div/input") }
    
    //#1 Improvesleep locators
    get isTitle () { return $('//*[@id="sl-flow"]/div[3]/div/div/div[1]/div/div[1]') }    
    get isOption1 () { return $('//*[@id="sl-flow"]/div[3]/div/div/div[1]/div/div[2]/div/div/div[1]/label') }
    get isOption2 () { return $('//*[@id="sl-flow"]/div[3]/div/div/div[1]/div/div[2]/div/div/div[2]/label') }
    get isOption3 () { return $('//*[@id="sl-flow"]/div[3]/div/div/div[1]/div/div[2]/div/div/div[3]/label') }
    get isOption4 () { return $('//*[@id="sl-flow"]/div[3]/div/div/div[1]/div/div[2]/div/div/div[4]/label') }
    get isOption5 () { return $('//*[@id="sl-flow"]/div[3]/div/div/div[1]/div/div[2]/div/div/div[5]/label') }    

    //#2 problemsleep locators
    get psTitle () { return $('//*[@id="sl-flow"]/div[3]/div/div/div[1]/div/div[1]') } 
    
    /**
     * Verify the options listed under each of the questions
     * @param {String} tag This is the indicator in json to get expected value which we need 
     * to compare with actual value fetched form application at run time
     */
    verifyQuestionsAndOptions(tag){        
        assert.strictEqual(questions[tag].title,this.isTitle.getText())
        assert.strictEqual(questions[tag].option1,this.isOption1.getText())
        assert.strictEqual(questions[tag].option2,this.isOption2.getText())
        assert.strictEqual(questions[tag].option3,this.isOption3.getText())
        assert.strictEqual(questions[tag].option4,this.isOption4.getText())
        assert.strictEqual(questions[tag].option5,this.isOption5.getText())
    }

    selectAnswers(anserKey){
        //@@@ Hardcoded
        var obj = options.Mild;

        Object.keys(obj).forEach(function(key) {
                        
            switch (obj[key].type){
                case 'button':
                    const listOfOptions = obj[key].value.split(',');
                    listOfOptions.forEach(opt => {
                        $("//*[contains(text(),'"+opt.trim()+"')]/following::input[@type='checkbox' or @type='radio'][1]").click()                        
                    });
                    break;
                case 'dropdown':
                    const element = $('[data-semantic-id="'+obj[key].locator+'"]').$('.sl-select')
                    element.selectByVisibleText(obj[key].value)
                    break;
                case 'textbox':
                    const ele = $('[data-semantic-id="'+obj[key].locator+'"]').$('.sl-input-number')
                    ele.setValue(obj[key].value)                    
                    break;
                case 'multi-dropdown':
                    const listOfOptions2 = obj[key].value.split(',');                    
                    $('[data-semantic-id="'+obj[key].locator+'"]').$('#select-month').selectByVisibleText(listOfOptions2[0])
                    $('[data-semantic-id="'+obj[key].locator+'"]').$('#select-day').selectByVisibleText(listOfOptions2[1])
                    $('[data-semantic-id="'+obj[key].locator+'"]').$('#select-year').selectByVisibleText(listOfOptions2[2])
                    break;
                case 'signup':
                    const textvalue = obj[key].value.split(',');  
                    $('//*[@name="first_name"]').setValue(textvalue[0])
                    $('//*[@name="last_name"]').setValue(textvalue[1])                    
                    $('//*[@name="email"]').setValue(textvalue[2])
                    //$('//*[@name="password"]').setvalue(textvalue[3])
                    break;                    
                default:
            }

            if(key!='signup') { $("//*[contains(text(),'Continue')]").click()}
            
        });
        //browser.debug()
    }

    selectAnswerAndVerify(arg1){
        const listOfOptions = arg1.split(',');
        listOfOptions.forEach(opt => {
            $("//*[contains(text(),'"+opt.trim()+"')]/following::input[@type='checkbox']").click()
        });
        this.continue.click()
        assert.strictEqual(true, this.psTitle.isExisting())        
    }
}

module.exports = new questionairePage();
