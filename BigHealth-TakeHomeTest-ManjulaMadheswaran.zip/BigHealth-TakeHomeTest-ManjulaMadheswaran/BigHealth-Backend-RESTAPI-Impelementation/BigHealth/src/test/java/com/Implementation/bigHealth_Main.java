package com.Implementation;

import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.APIOperations.bigHealth_Operations;

/**
 * @author Manjula Madheswaran Implementation Main File
 */
public class bigHealth_Main {

// Variable declaration and Initialisation
	public String loggerName = "automation";
	public Logger logger = LoggerFactory.getLogger(loggerName);

	public String testData = "",testDataSets="",level="";
	protected bigHealth_Operations bigHealth_operations;
	static String cookie = "";

	@BeforeClass
	@Parameters({ "testData" , "testDataSets" , "level" })
	public void configuration(String testData,String testDataSets, String level) throws Exception {

		//testData and testDataSets and level are the parameters to pass the input value via suite file
		// split the excel data and convert it into two dimensional object inputs

		bigHealth_operations = new bigHealth_Operations();

	}

	@DataProvider(name = "bigHealth")
	public Object[][] bigHealthValidations() throws Exception {
		 return new Object[][]{{ "" }}; // Enhancement xls mode of operation to be covered later
	}

	/**
	 * Validating bigHealth Operations
	 * @throws Exception
	 */

	@Test(dataProvider = "bigHealth")
	public void bigHealthValidations(String inputData) throws Exception {

		// Variable declaration and Initialisation
		String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		logger.info("\n>> API  - Starts >>" + "Method - " + methodName + "\n");

		boolean flag = false;
		String failureMessage = "";
		Map<String, Object> getbigHealthDetails = new HashMap<String, Object>();
		try {

			//Validate API
			getbigHealthDetails = bigHealth_operations.getBigHealthDetails();
			logger.info("get big Health Details ->" + getbigHealthDetails);

			//logic can be performed here based on the requirement
			if(!getbigHealthDetails.isEmpty()){
				flag=true;
			}

		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
			throw new SkipException("Generic exception observed during the run ->" + e);
		}

		logger.debug(">> API  - Ends >>" + "Method - " + methodName + "\n\n");
		Assert.assertEquals(flag, true, failureMessage);

	}

}
