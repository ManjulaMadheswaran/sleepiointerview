
module.exports = class Page {
    /**
    * Opens a sub page of the page
    * @param path url which needs to be launched
    */
    open (path) {        
        return browser.url(path)
    }
}
