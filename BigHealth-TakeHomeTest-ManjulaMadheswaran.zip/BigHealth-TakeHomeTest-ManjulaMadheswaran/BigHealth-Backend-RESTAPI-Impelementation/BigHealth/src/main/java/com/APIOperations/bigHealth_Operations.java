package com.APIOperations;
import com.Common.RestAPIDefinitions;
import java.util.*;

import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.builder.ResponseSpecBuilder;
import org.hamcrest.Matchers;
import org.slf4j.*;
import org.testng.Assert;
import org.testng.SkipException;

/**
 * @author Manjula Madheswaran
 * API Invoking File
 */

public class bigHealth_Operations {
	
	// Variable declaration and Initialisation
	public static String loggerName = "automation";
    public static Logger logger=LoggerFactory.getLogger(loggerName);

	/**
	 * GET Operation - To fetch bighealth details
	 * @return Retrieve bighealth details
	 */

	public Map<String, Object> getBigHealthDetails()
	{
	//Variable Declaration and Initialisation
	String methodName =Thread.currentThread().getStackTrace()[1].getMethodName();
	logger.info("\n>>CallingMethod - Starts >>" +"Method - " + methodName +"\n\n");

	Map<String, Object> resultantData = new HashMap<String, Object>();
	Map<String, Object> nearest = new HashMap<String, Object>();
	String url = "",responseBody="",failureMessage="";

	try
	{
		url = RestAPIDefinitions.get_bighealth;

		//URL to fetch the expected Data
		logger.info("REST API CALL -> "+ url);
	
		//Performing GET Operation
		 Map<String,Object> response = sendHttpRequest(url, "GET");
		 logger.info("Get Response ->"+response);

		if(RestAPIDefinitions.sucessCode.equalsIgnoreCase(response.get("statusCode").toString())) {
			logger.info("Obtained Success status codes");
			resultantData.putAll(response);
		}
		else {
			failureMessage="Retrieved failed status code for given API :\n"+url+" Expected : 200,Retrieved : "+response.get("statusCode").toString();
			logger.info(failureMessage);
			Assert.fail(failureMessage);
		}
	}
	catch(Exception ex) {
		ex.printStackTrace();
		throw new SkipException("Exception found in the common function while fetching the data"+ex.getMessage());
	}
	    logger.debug("\n>>CallingMethod - Ends >>" +"Method - " + methodName +"\n\n");
		return resultantData;
	}
	
	/**
	 * API Calls - To Perform REST Operations - GET / POST / PUT / DELETE
	 * @param url
	 * @param actionType
	 * @return
	 */
	public static Map<String,Object> sendHttpRequest(String url,String actionType)
	{

		//Variable Declarations and Initialisations

		String methodName =Thread.currentThread().getStackTrace()[1].getMethodName();
		logger.debug("\n>>CallingMethod - Starts >>" +"Method - " + methodName );

		Map<String,Object> resultResponse = new HashMap<String,Object>();
		String resultStatusCode="";
		try {
			Long MAX_TIMEOUT = 2000l;
			ResponseSpecBuilder resBuilder = new ResponseSpecBuilder();
			resBuilder.expectResponseTime(Matchers.lessThan(MAX_TIMEOUT));
			RestAssured.responseSpecification = resBuilder.build();

			if(actionType.equalsIgnoreCase("GET")) {

				Response response = (Response) given().get(url);
				System.out.println("Time Taken for the api call in ms :"+response.getTime());

				resultResponse.put("statusCode",response.getStatusCode());
				resultResponse.put("responseTime",response.getTime());
				//resultResponse.put("responseBody",response.getBody().asString());
				resultResponse.put("cookies",response.getCookies());
				resultResponse.put("Headers",response.getHeaders());

			}else if(actionType.equalsIgnoreCase("POST")) {
				//To do POST or PUT or DELETE actionTypes.

				/*	JSONArray jsonObj ={ }; // later based on the requirement we can pass the paramters
				Response response = (Response) given().header("Content-Type","application/json")
						.contentType(ContentType.JSON) //just for expecting json data
						.accept(ContentType.JSON) //just for expecting json data
						.body(jsonObj.toJSONString()).post(url);
				System.out.println("Time Taken for the api call in ms :"+response.getTime());*/

			}else{
				Assert.fail("Please check the given REST Method TYPE / whether it is implemented in logic. Failed to perform the operation");
			}

		}
		catch(Exception ex) {
			throw new SkipException("Found Generic Exception while performing http operation: " + ex.getMessage());
		}
		logger.debug("\n>>CallingMethod - Ends >>" +"Method - " + methodName );
		return resultResponse;		
	}

}
