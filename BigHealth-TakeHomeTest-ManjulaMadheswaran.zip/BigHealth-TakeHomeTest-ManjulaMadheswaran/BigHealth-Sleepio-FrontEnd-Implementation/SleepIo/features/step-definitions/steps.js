const landingPage = require('../pageobjects/landingPage');
const questionairePage = require('../pageobjects/questionairePage');
const { Given, When, Then } = require('cucumber');
const assert = require('assert')
Given(/^I am on the landing page$/, () => {
    landingPage.open()
});

When(/^I click on get started$/, () => {
    landingPage.clickGetStarted()
});

When(/^I answer the (.*)$/, (key) => {
    landingPage.clickGetStarted()
    questionairePage.selectAnswers(key)
});

Then(/^I should see the (.*)$/,(questionaire)=>{
    questionairePage.verifyQuestionsAndOptions(questionaire)
});

Then(/^I select the (.*) and verify it$/,(option)=>{
    //questionairePage.navigate(questionName)
    questionairePage.selectAnswerAndVerify(option)
});

Then(/^I should see my (.*)$/,(score)=>{
    assert.strictEqual(true,true)
    //Not submitting to assert the scores
});
